$(function() {
			$('#myTab2 a').hover(function() {
				$(this).tab('show');
			});
		})